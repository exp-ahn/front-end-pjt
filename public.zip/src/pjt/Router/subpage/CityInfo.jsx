import React from 'react';

const CityInfo = () => {
    return <></>;
};

export default CityInfo;
