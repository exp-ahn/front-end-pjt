import React from 'react';

const WeatherInfo = () => {
    return <></>;
};

export default WeatherInfo;
