import React from 'react';

const TrafficInfo = () => {
    return <></>;
};

export default TrafficInfo;
