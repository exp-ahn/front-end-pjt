import React from "react";

const Details = () => {
    return(
        <>
        </>
    );
}

export default Details;