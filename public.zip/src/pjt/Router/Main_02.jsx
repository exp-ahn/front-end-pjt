import React from "react";

const Main_02 = () => {
    return(
        <>
        </>
    );
}

export default Main_02;